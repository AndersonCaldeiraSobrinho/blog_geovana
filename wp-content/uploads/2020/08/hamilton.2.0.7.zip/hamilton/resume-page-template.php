<?php 

/* Template Name: Resume */

/* We only need the page template specific body_class for styling – other than that, the page template is exactly the same as all other singulars. Because of this, we can just include the singular template here. */

include( locate_template( 'singular.php' ) ); ?>